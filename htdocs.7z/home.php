<?php
require_once('global.php');
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.101.0">
    <title><?php echo SITE_NAME ?></title>

    <link rel="shortcut icon" href="dino.png" type="image/x-icon">

    <script src="<?php echo ASSETS_URL ?>js/script.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    
    <!-- Custom styles for this template -->
    <link href="<?php echo ASSETS_URL ?>css/style.css" rel="stylesheet">
  </head>
  <body>
    
<header class="site-header sticky-top py-1">
    <nav class="container d-flex flex-column flex-md-row justify-content-between">
        
        <a href="" class="py-2 text-center" style="position: relative; margin-left: 30%; color: lime;"  href="<?php echo SITE_URL ?>home.php">Bem-vindo(a), <?php echo $_SESSION['userInfo']['nome']; ?></a>
        
        <!-- logout --> 
        <a class="py-2 d-none d-md-inline-block" href="<?php echo SITE_URL ?>logout.php">Sair</a>
        
    </nav>
</header>

<main>
    
    <div class="container">
        <br><br>
        
        <!-- create 3 cards --> 
        <img src="dinocard.png" alt="" srcset="">


        <div class="cartaodino" >
    
        
    <span class="nomecartao"><?php echo $_SESSION['userInfo']['nome']; ?></span>
        </div>

<div class="row row-cols-1 row-cols-md-3 g-4" style="margin-top: 5%;">
  <div class="col-md-4">
    <div class="card">
      <img src="<?php echo ASSETS_URL ?>images/transfer.png" class="card-img-top" alt="...">
        <div class="card-body">
        <h5 class="card-title">Saldo</h5>
        <p class="card-text">R$<?php echo $user->getUserSaldo($_SESSION['userInfo']['id']);  ?></p>
        <a href="<?php echo SITE_URL ?>transfer.php" class="btn btn-primary">Transferir</a>
        </div>
    </div>
    </div>
  <div class="col-md-4">
    <div class="card">
      <img src="<?php echo ASSETS_URL ?>images/transfer.png" class="card-img-top" alt="...">
        <div class="card-body">
        <h5 class="card-title">Crédito</h5>
        <p class="card-text">quanto vc deve</p>
        <a href="<?php echo SITE_URL ?>transfer.php" class="btn btn-primary">Transferir</a>
        </div>
    </div>
    </div>
  <div class="col-md-4">
    <div class="card">
      <img src="<?php echo ASSETS_URL ?>images/transfer.png" class="card-img-top" alt="...">
        <div class="card-body">
        <h5 class="card-title">###</h5>
        <p class="card-text">Realize transferências para outras contas.</p>
        <a href="<?php echo SITE_URL ?>transfer.php" class="btn btn-primary">Transferir</a>
        </div>
    </div>
    </div>







</div>


  
</main>

<footer class="container py-5">
  <div class="row">
    <div class="col-12 col-md">
        <img src="dino.png" alt="" height="32" width="32" class="d-block mb-2">
        DinoBank
    <small class="d-block mb-3 text-muted">&copy; 2022 - <?php echo date('Y'); ?></small>
    </div>
  
    <div class="col-6 col-md">
      <h5>Recursos</h5>
      <ul class="list-unstyled text-small">
        <li><a class="link-secondary" href="#">Resource name</a></li>
        <li><a class="link-secondary" href="#">Resource</a></li>
        <li><a class="link-secondary" href="#">Another resource</a></li>
        <li><a class="link-secondary" href="#">Final resource</a></li>
      </ul>
    </div>
    <div class="col-6 col-md">
      <h5>Dino</h5>
      <ul class="list-unstyled text-small">
        <li><a class="link-secondary" href="#">Business</a></li>
        <li><a class="link-secondary" href="#">Education</a></li>
        <li><a class="link-secondary" href="#">Government</a></li>
        <li><a class="link-secondary" href="#">Gaming</a></li>
      </ul>
    </div>
    <div class="col-6 col-md">
      <h5>Sobre</h5>
      <ul class="list-unstyled text-small">
        <li><a class="link-secondary" href="#">Equipe</a></li>
        <li><a class="link-secondary" href="#">Agências</a></li>
        <li><a class="link-secondary" href="#">Privacidade</a></li>
        <li><a class="link-secondary" href="#">Termos</a></li>
      </ul>
    </div>
  </div>
</footer>

<style>
    .nomecartao{
        position: relative;
        top: 50%;
        left: 65%;
        font-size: 20px;
        color: darkgreen;
    }

    .cartaodino {
        background-image: url('dino.png');
        height: 250px;
        width: 500px; 
        background-color: darkgreen;
        border-radius: 10px; 
        background-repeat: no-repeat; 
        background-position: center;
    }
    .cartaodino:hover {
        background-color: rgb(36,255,0, 13%);
    }
  
</style>

<script src="<?php echo ASSETS_URL ?>js/jquery-3.3.1.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  </body>
</html>

