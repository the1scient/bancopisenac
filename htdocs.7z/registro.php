<?php include_once('global.php'); 

if(@isset($_SESSION['id'])) {
  header("Location: ".SITE_URL."home.php");
  exit;
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo ASSETS_URL ?>fonts/icomoon/style.css">

    <link rel="stylesheet" href="<?php echo ASSETS_URL ?>css/owl.carousel.min.css">

    <link rel="shortcut icon" href="dino.png" type="image/x-icon">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    
    <!-- Style -->
    <link rel="stylesheet" href="<?php echo ASSETS_URL ?>css/login.css">

    <title><?php echo SITE_NAME ?> - Registro</title>
  </head>
  <body>
  

  
  <div class="content">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <img src="<?php echo ASSETS_URL ?>images/login.jpg" alt="Image" class="img-fluid">
        </div>
        <div class="col-md-6 contents">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="mb-4">
              <h3>Registre-se</h3>
              <p class="mb-4">Crie sua conta no banco mais moderno do mundo.</p>
            </div>
            <form action="<?php echo SITE_URL ?>kernel/registro.php" method="post">

              <div class="form-group first">
                <label for="username">Nome e Sobrenome</label>
                <input type="text" name="nome" class="form-control" id="nome" required>
              </div>

              <div class="form-group first">
                <label for="username">CPF</label>
                <input type="text" name="cpf" class="form-control" id="cpf" required>
              </div>
              <div class="form-group last mb-4">
                <label for="password">Senha</label>
                <input type="password" name="password" class="form-control" id="password" required>
              </div>
              <div class="form-group first">
                <label for="username">Endereço</label>
                <input type="text" name="endereco" class="form-control" id="nome" required>
              </div>

              <div class="form-group first">
                <label for="username">Telefone</label>
                <input type="text" name="telefone" class="form-control" id="telefone" required>
              </div>
              <div class="form-group first">
                <label for="username">E-mail</label>
                <input type="email" name="email" class="form-control" id="nome" required>
              </div>
              

<br>

              <div class="d-flex mb-5 align-items-center">
                
                <span class="ml-auto"><a href="#" class="forgot-pass">Deseja fazer Log In?</a></span> 
              </div>

              <input type="submit" value="Criar conta" class="btn btn btn-success">
              
            </form>
            </div>
          </div>
          
        </div>
        
      </div>
    </div>
  </div>

  
    <script src="<?php echo ASSETS_URL ?>js/jquery-3.3.1.min.js"></script>
    <script src="<?php echo ASSETS_URL ?>js/popper.min.js"></script>
    <script src="<?php echo ASSETS_URL ?>js/bootstrap.min.js"></script>
    <script src="<?php echo ASSETS_URL ?>js/main.js"></script>
      <!-- jquery mask cdn -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
      <script>
        $(document).ready(function(){
          $('#cpf').mask('000.000.000-00');
          $('#telefone').mask('(00) 00000-0000');
        });
      </script>


  </body>
</html>