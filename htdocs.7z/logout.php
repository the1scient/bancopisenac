<?php 
require_once('global.php');
// logout - delete session
@session_destroy();
header("Location: ".SITE_URL."index.php");
exit;