<?php

class User {

    public function getUserSaldo($userId) {

        global $pdo;

        $sql = $pdo->prepare("SELECT saldo FROM usuarios WHERE id = :id");
        $sql->bindValue(':id', $userId);
        $sql->execute();

        return $sql->fetchColumn();

    }





}