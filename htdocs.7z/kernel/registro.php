<?php 
require_once('configs.php');

$nome = htmlspecialchars($_POST['nome']);
$cpf = $_POST['cpf'];

// remove all illegal characters from cpf
$cpf = preg_replace("/[^0-9]/", "", $cpf);
$password = htmlspecialchars($_POST['password']);
$endereco = htmlspecialchars($_POST['endereco']);
$telefone = htmlspecialchars($_POST['telefone']);
$email = htmlspecialchars($_POST['email']);



$sql = $pdo->prepare("SELECT * FROM usuarios WHERE cpf = :cpf");
$sql->bindValue(':cpf', $cpf);
$sql->execute();

if($sql->rowCount() > 0) {
  echo "Já possui conta no site";
}
else {
 // não tem conta no site - criar conta

    $sql = $pdo->prepare("INSERT INTO usuarios (email, nome, cpf, senha, endereco) VALUES (:email, :nome, :cpf, :senha, :endereco)");
    $sql->bindValue(':nome', $nome);
    $sql->bindValue(':cpf', $cpf);
    $sql->bindValue(':senha', md5($password));
    $sql->bindValue(':endereco', $endereco);
    $sql->bindValue(':email', $email);
    $sql->execute();

    echo "Conta criada com sucesso";
    header('Location: '.SITE_URL.'login.php');

}

?>