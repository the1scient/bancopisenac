<?php
require_once('kernel/configs.php');
require_once('kernel/Classes/User.php');

$user = new User();
